package com.fastclicker.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Draws a draggable target and a small control bar on top of other apps, and taps the target
 * as fast as the phone allows.
 *
 * Speed trick: instead of one tap per dispatchGesture() call (slow, ~20-40 per second at best),
 * each call carries up to 20 tiny 1 ms taps spaced a few milliseconds apart. The spacing is
 * adjusted on the fly so the real rate lands on the number the user asked for.
 */
public class ClickService extends AccessibilityService {

    static final String PREFS = "fastclicker";
    static final int MIN_CPS = 1;
    static final int MAX_CPS = 500;

    private static final int OVERLAY_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    /** Non-null while the accessibility service is connected. */
    static volatile ClickService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;

    // Overlay views
    private View targetView;
    private WindowManager.LayoutParams targetLp;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private TextView startBtn;
    private TextView cpsLabel;
    private GradientDrawable startBg;

    // Clicking state (main thread only)
    private boolean running;
    private int runId;
    private int cps = 100;
    private int tx, ty;
    private long nextDue;
    private long tapsDone, tapsAtTick, lastTick;
    private double overheadMs = 25; // estimated system latency added to every gesture

    private final Runnable fireRunnable = new Runnable() {
        @Override
        public void run() {
            fireBatch();
        }
    };

    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long now = SystemClock.uptimeMillis();
            long dt = now - lastTick;
            if (dt > 0 && cpsLabel != null) {
                long actual = Math.round((tapsDone - tapsAtTick) * 1000.0 / dt);
                cpsLabel.setText(cps + " \u2192 " + actual);
                tapsAtTick = tapsDone;
                lastTick = now;
            }
            handler.postDelayed(this, 500);
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        cps = clamp(getSharedPreferences(PREFS, MODE_PRIVATE).getInt("cps", 100));
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Not used: this service only sends taps, it never reads the screen.
    }

    @Override
    public void onInterrupt() {
        stopClicking();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        hideOverlay();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        hideOverlay();
        instance = null;
        super.onDestroy();
    }

    static int clamp(int v) {
        return Math.max(MIN_CPS, Math.min(MAX_CPS, v));
    }

    // ---------------------------------------------------------------- public API (used by MainActivity)

    void showOverlay(int requestedCps) {
        cps = clamp(requestedCps);
        if (wm == null) return;
        if (panel != null) {
            resetPositions();
            updateCpsLabel();
            return;
        }
        buildTarget();
        buildPanel();
        updateCpsLabel();
    }

    void hideOverlay() {
        stopClicking();
        removeOverlayView(panel);
        removeOverlayView(targetView);
        panel = null;
        targetView = null;
        startBtn = null;
        cpsLabel = null;
        startBg = null;
    }

    // ---------------------------------------------------------------- clicking

    private void startClicking() {
        if (running || targetView == null) return;

        int[] loc = new int[2];
        targetView.getLocationOnScreen(loc);
        tx = Math.max(0, loc[0] + targetView.getWidth() / 2);
        ty = Math.max(0, loc[1] + targetView.getHeight() / 2);

        // Let taps pass through the target ring to the app underneath.
        setTargetClickThrough(true);

        running = true;
        runId++;
        tapsDone = 0;
        tapsAtTick = 0;
        lastTick = SystemClock.uptimeMillis();

        startBtn.setText("STOP");
        startBg.setColor(0xFFC62828);

        handler.removeCallbacks(fireRunnable);
        handler.removeCallbacks(tickRunnable);
        handler.postDelayed(fireRunnable, 120); // give the window flag change a moment to apply
        handler.postDelayed(tickRunnable, 500);
    }

    private void stopClicking() {
        if (!running) return;
        running = false;
        runId++;
        handler.removeCallbacks(fireRunnable);
        handler.removeCallbacks(tickRunnable);
        setTargetClickThrough(false);
        if (startBtn != null && startBg != null) {
            startBtn.setText("START");
            startBg.setColor(0xFF2E7D32);
        }
        updateCpsLabel();
    }

    private void fireBatch() {
        if (!running) return;

        final int rate = cps;
        final int maxStrokes = Math.min(20, GestureDescription.getMaxStrokeCount());
        final int n = Math.max(1, Math.min(maxStrokes, (int) Math.round(rate * 0.15)));
        final double period = n * 1000.0 / rate; // how long this batch should take, in ms

        // Spread the taps so that (gesture length + system overhead) is about one period.
        double spacing = 0;
        if (n > 1) {
            spacing = (period - 1 - overheadMs) / (n - 1);
            if (spacing < 2) spacing = 2; // never let two taps overlap
        }

        GestureDescription.Builder builder = new GestureDescription.Builder();
        long lastStart = 0;
        for (int i = 0; i < n; i++) {
            Path p = new Path();
            p.moveTo(tx, ty);
            lastStart = Math.round(i * spacing);
            builder.addStroke(new GestureDescription.StrokeDescription(p, lastStart, 1));
        }

        final int myRun = runId;
        final int sent = n;
        final long expected = lastStart + 1;
        final long sentAt = SystemClock.uptimeMillis();
        nextDue = sentAt + Math.round(period);

        boolean accepted = dispatchGesture(builder.build(),
                new AccessibilityService.GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        if (!running || myRun != runId) return;
                        long now = SystemClock.uptimeMillis();
                        tapsDone += sent;
                        if (sent > 1) {
                            double o = (now - sentAt) - expected;
                            o = Math.max(0, Math.min(300, o));
                            overheadMs = overheadMs * 0.7 + o * 0.3;
                        }
                        handler.postDelayed(fireRunnable, Math.max(0, nextDue - now));
                    }

                    @Override
                    public void onCancelled(GestureDescription gestureDescription) {
                        if (!running || myRun != runId) return;
                        handler.postDelayed(fireRunnable, 20);
                    }
                }, handler);

        if (!accepted) {
            stopClicking();
            Toast.makeText(this, "Android refused the taps. Turn the service off and on again in Accessibility settings.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void adjustCps(int direction) {
        int step = cps < 20 ? 1 : (cps < 100 ? 5 : 10);
        cps = clamp(cps + direction * step);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("cps", cps).apply();
        if (!running) updateCpsLabel();
    }

    private void updateCpsLabel() {
        if (cpsLabel != null) cpsLabel.setText(cps + " CPS");
    }

    // ---------------------------------------------------------------- overlay UI

    private void buildTarget() {
        final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(3));
        stroke.setColor(0xFFFF3B30);

        targetView = new View(this) {
            @Override
            protected void onDraw(Canvas c) {
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) - dp(4);
                c.drawCircle(cx, cy, r, stroke);
                c.drawLine(cx - r, cy, cx + r, cy, stroke);
                c.drawLine(cx, cy - r, cx, cy + r, stroke);
            }
        };

        int size = dp(56);
        DisplayMetrics m = getResources().getDisplayMetrics();
        targetLp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                OVERLAY_FLAGS,
                PixelFormat.TRANSLUCENT);
        targetLp.gravity = Gravity.TOP | Gravity.START;
        targetLp.x = m.widthPixels / 2 - size / 2;
        targetLp.y = m.heightPixels / 2 - size / 2;
        // Android 12+ only lets touches pass through overlays that are at most 80% opaque.
        targetLp.alpha = 0.75f;

        makeDraggable(targetView, targetView, targetLp);
        wm.addView(targetView, targetLp);
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0212121);
        bg.setCornerRadius(dp(26));
        panel.setBackground(bg);

        TextView handle = makeButton("\u2630", 0);
        startBtn = makeButton("START", 0xFF2E7D32);
        startBg = (GradientDrawable) startBtn.getBackground();
        startBtn.setMinWidth(dp(76));
        TextView minus = makeButton("-", 0xFF424242);
        cpsLabel = makeButton("", 0);
        cpsLabel.setMinWidth(dp(92));
        TextView plus = makeButton("+", 0xFF424242);
        TextView close = makeButton("X", 0xFFB71C1C);

        addToPanel(handle);
        addToPanel(startBtn);
        addToPanel(minus);
        addToPanel(cpsLabel);
        addToPanel(plus);
        addToPanel(close);

        startBtn.setOnClickListener(v -> {
            if (running) stopClicking();
            else startClicking();
        });
        minus.setOnClickListener(v -> adjustCps(-1));
        plus.setOnClickListener(v -> adjustCps(1));
        close.setOnClickListener(v -> hideOverlay());

        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                OVERLAY_FLAGS,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(16);
        panelLp.y = dp(120);

        makeDraggable(handle, panel, panelLp);
        wm.addView(panel, panelLp);
    }

    private void resetPositions() {
        DisplayMetrics m = getResources().getDisplayMetrics();
        targetLp.x = m.widthPixels / 2 - targetLp.width / 2;
        targetLp.y = m.heightPixels / 2 - targetLp.height / 2;
        panelLp.x = dp(16);
        panelLp.y = dp(120);
        try {
            wm.updateViewLayout(targetView, targetLp);
            wm.updateViewLayout(panel, panelLp);
        } catch (RuntimeException ignored) {
            // view was already gone
        }
    }

    private void setTargetClickThrough(boolean through) {
        if (targetView == null || !targetView.isAttachedToWindow()) return;
        if (through) {
            targetLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            targetLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }
        try {
            wm.updateViewLayout(targetView, targetLp);
        } catch (RuntimeException ignored) {
            // view was already gone
        }
    }

    private void removeOverlayView(View v) {
        if (v == null || wm == null) return;
        try {
            wm.removeView(v);
        } catch (RuntimeException ignored) {
            // view was already gone
        }
    }

    private void makeDraggable(View handle, final View windowView, final WindowManager.LayoutParams lp) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = startX + Math.round(e.getRawX() - downX);
                        lp.y = startY + Math.round(e.getRawY() - downY);
                        try {
                            wm.updateViewLayout(windowView, lp);
                        } catch (RuntimeException ignored) {
                            // view was already gone
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    private TextView makeButton(String text, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(9), dp(12), dp(9));
        if (color != 0) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(color);
            g.setCornerRadius(dp(20));
            t.setBackground(g);
        }
        return t;
    }

    private void addToPanel(View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(2), 0, dp(2), 0);
        panel.addView(v, lp);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
