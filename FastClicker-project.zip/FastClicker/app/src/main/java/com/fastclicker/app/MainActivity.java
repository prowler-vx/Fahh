package com.fastclicker.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView status;
    private EditText cpsInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(20);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        root.addView(text("Fast Clicker", 28, true));

        status = text("", 16, false);
        status.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(status);

        Button enable = new Button(this);
        enable.setText("1. Turn on in Accessibility settings");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(enable);

        TextView label = text("2. Clicks per second (1\u2013500)", 16, false);
        label.setPadding(0, pad, 0, 0);
        root.addView(label);

        cpsInput = new EditText(this);
        cpsInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        cpsInput.setText(String.valueOf(
                getSharedPreferences(ClickService.PREFS, MODE_PRIVATE).getInt("cps", 100)));
        root.addView(cpsInput);

        Button show = new Button(this);
        show.setText("3. Show floating controls");
        show.setOnClickListener(v -> showControls());
        root.addView(show);

        TextView help = text(
                "Then open the app you want to click in, drag the red target onto the spot, "
                        + "and tap START on the floating bar. Tap STOP to stop. "
                        + "Keep the bar away from the target.\n\n"
                        + "On the bar, the number after the arrow is the speed your phone is "
                        + "really reaching. If it is lower than your target, raise the target.\n\n"
                        + "Switch greyed out (Android 13+)? Settings > Apps > Fast Clicker > "
                        + "menu (three dots) > Allow restricted settings, then try again.",
                14, false);
        help.setPadding(0, pad, 0, 0);
        root.addView(help);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText(ClickService.instance != null
                ? "Status: ready"
                : "Status: accessibility service is OFF");
    }

    private void showControls() {
        ClickService service = ClickService.instance;
        if (service == null) {
            Toast.makeText(this, "Turn Fast Clicker on in Accessibility settings first",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        int cps = ClickService.clamp(parseInput());
        cpsInput.setText(String.valueOf(cps));
        getSharedPreferences(ClickService.PREFS, MODE_PRIVATE).edit().putInt("cps", cps).apply();
        service.showOverlay(cps);
        moveTaskToBack(true);
    }

    private int parseInput() {
        try {
            return Integer.parseInt(cpsInput.getText().toString().trim());
        } catch (NumberFormatException e) {
            return 100;
        }
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
