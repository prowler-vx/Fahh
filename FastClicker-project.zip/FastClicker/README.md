# Fast Clicker

Android auto clicker. One tap target, adjustable 1-500 clicks per second, floating START/STOP bar.

## Build the APK
**Android Studio:** open this folder, wait for Gradle sync, then Build > Build APK(s).
The file is app/build/outputs/apk/debug/app-debug.apk.

**GitHub (no install):** put this folder (or the zip plus build.yml) in a repo. build.yml must live at
.github/workflows/build.yml. The Actions tab builds it; download the FastClicker-APK artifact.

## Use it
1. Install the APK, open Fast Clicker, turn it on in Accessibility settings
   (Android 13+: App info > three dots > Allow restricted settings first).
2. Set clicks per second, tap Show floating controls.
3. Drag the red target onto the spot, tap START.

## Notes
- Uses an accessibility service only to send taps. It does not read the screen.
- Each gesture carries up to 20 tiny taps, and spacing adapts so the real rate lands near your target.
  The bar shows target -> actual. Real speed depends on the phone and the app being tapped.
